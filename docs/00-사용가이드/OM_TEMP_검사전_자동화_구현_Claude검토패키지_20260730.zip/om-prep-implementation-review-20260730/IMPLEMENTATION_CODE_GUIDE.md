# OM_TEMP 검사 전 준비 자동화 구현·코드 안내

> 기준일: 2026-07-30
>
> 거버넌스 저장소: `easyseop/openmetadata-test`
>
> 작업 branch: `codex/strict-manifest-gates`
>
> 구현 commit: `b63ce67bd303865224339a0dfe6e4becb252bea6`

## 1. 무엇을 자동화했나

OpenMetadata 커스터마이징 코드를 commit한 뒤, 검사에 필요한 등록자료의
변경안을 만드는 과정을 자동화했다.

```text
OM_TEMP의 patch/custom branch
  → plan: Git commit·BANK-OM ID·변경 경로 자동 분석
  → 사람이 required·Contract·watch·owner를 검토하고 승인
  → apply: 승인한 동일 제안만 등록자료에 반영
  → 등록자료 검사와 소스 검사 실행
```

자동화는 Git이 직접 증명할 수 있는 SHA, commit 순서, BANK-OM ID와 변경
경로만 계산한다. 기능의 필수 파일, 업무 정상 조건, 담당자, 중요도와 충돌 해결
코드는 사람이 결정한다.

## 2. 실행 진입점

### `harness/prepare_registration.py`

운영자가 직접 실행하는 CLI다. 세 명령만 제공한다.

| 명령 | 실제 동작 | 등록자료 수정 여부 |
|---|---|---|
| `plan` | patch와 custom을 비교해 제안·질문·diff를 생성 | 수정하지 않음 |
| `approval-template` | 한 제안 digest에 연결된 미승인 양식 생성 | 수정하지 않음 |
| `apply` | 승인서와 제안이 정확히 일치할 때 변경 적용 | 승인된 파일만 수정 |

종료 상태는 `READY`, `REVIEW_REQUIRED`, `BLOCKED`, `ANALYSIS_ERROR`,
`APPLIED`로 구분한다. `READY`도 자동 승인을 의미하지 않는다.

## 3. 핵심 구현 파일

| 파일 | 담당하는 기능 |
|---|---|
| `harness/acgh/registration_prep.py` | Git 분석, 기존 정책 비교, 제안 생성, 승인 검증, 원자 적용과 rollback |
| `harness/acgh/gitprim.py` | ref를 commit SHA로 고정하고 commit·경로·tree entry·blob을 안전하게 읽음 |
| `harness/acgh/candidate.py` | 검사 대상 Candidate lock 생성·검증. 소스와 실제 build artifact를 구분 |
| `harness/acgh/binding.py` | Candidate lock과 검사 결과가 같은 코드·artifact를 가리키는지 확인 |
| `harness/acgh/schema/commit-inventory.schema.json` | BANK-OM별 commit 이력 산출물 형식 |
| `harness/acgh/schema/registration-proposal.schema.json` | 자동 변경안·질문·차단·분석 오류 형식 |
| `harness/acgh/schema/registration-approval.schema.json` | 승인자와 질문별 판단을 기록하는 형식 |
| `harness/acgh/schema/candidate-lock.schema.json` | 최종 검사 대상의 SHA·tree·artifact 종류 형식 |

## 4. `plan` 내부 처리 순서

1. 제품 저장소와 버전별 등록 폴더를 읽는다.
2. patch/custom ref를 각각 고정된 commit SHA로 변환한다.
3. patch가 custom의 출발점인지 확인한다.
4. `patch..custom`의 모든 commit을 순서대로 읽는다.
5. 각 commit 본문의 `Customization-ID`를 정확히 하나만 찾는다.
6. BANK-OM별 commit SHA와 변경 파일을 합친다.
7. 현재 Manifest·Registry·Contract·경로 소유정보와 비교한다.
8. Git으로 확정 가능한 변경안과 사람이 판단할 질문을 분리한다.
9. 등록 폴더 밖에 변경 제안과 digest를 새로 만든다.

`plan`은 기존 Manifest를 덮어쓰지 않는다. 같은 출력 폴더가 이미 있으면
중단하므로 과거 제안도 그대로 보존된다.

## 5. 생성되는 파일과 사용 목적

| 파일 | 의미 | 누가 사용하는가 |
|---|---|---|
| `summary.md` | 상태와 자동 변경·사람 판단·차단 건수 | 최초 검토자 |
| `review-required.yaml` | 사람이 결정해야 할 질문과 관련 BANK-OM·경로 | 기능 담당자·승인자 |
| `diff.patch` | 승인 후 Manifest·Registry가 어떻게 바뀌는지 보여주는 diff | 코드 검토자 |
| `proposal.yaml` | 입력 SHA, 현재 등록자료 digest, 변경안과 질문 전체 | `apply`와 감사 담당자 |
| `proposal-digest.txt` | 제안 전체를 고정하는 SHA-256 | 승인서와 `apply` |
| `commit-inventory.yaml` | BANK-OM별 모든 commit SHA와 변경 파일 | Manifest 범위 검사·감사 |
| `current-diff-paths.txt` | patch와 custom의 최종 전체 변경 경로 | 전체 범위 검사 |
| `registration-approval.template.yaml` | 아직 승인되지 않은 자리표시자 양식 | 실제 승인자가 작성 |

현재 실제 예시는
`harness/preparation-plans/om-temp-1.13.0-20260730/`에 있다.

## 6. 자동으로 결정하는 것과 사람이 결정하는 것

| 자동 계산 | 사람 판단 |
|---|---|
| patch/custom commit SHA | 신규 BANK-OM의 담당자와 중요도 |
| commit별 BANK-OM ID | 누락 시 기능이 깨지는 required 파일 |
| BANK-OM별 전체 변경 파일 | 간접 영향만 받는 추가 watch 경로 |
| 현재 버전의 최종 diff | Contract의 업무 정상 조건과 필수 test |
| 기존 등록자료와의 불일치 | 충돌 해결 코드와 최종 승인 |
| 제안 digest와 stale 여부 | 운영 배포 여부 |

사람 판단이 남으면 `REVIEW_REQUIRED`다. 이는 검사 실패가 아니라 자동화가
업무 의미를 대신 결정하지 않았다는 뜻이다.

## 7. 안전을 위해 자동 중단하는 경우

- 제품 저장소에 미커밋 또는 untracked 파일이 있음
- patch와 custom이 올바른 직선 계보가 아님
- commit에 BANK-OM ID가 없거나 두 개 이상 있음
- merge commit 또는 변경 파일이 없는 commit
- 한 commit이 서로 다른 소유 영역을 함께 변경
- 같은 BANK-OM의 commit 사이에 다른 ID가 끼어 있음
- 폐기된 ID 재사용 또는 필수 파일 소실
- 분류할 수 없는 경로
- symlink, submodule 또는 Git LFS pointer
- 승인 후 patch/custom ref나 등록자료가 변경됨
- 다른 작업자가 동시에 `apply` 중임

차단 문제는 정책을 완화해 통과시키지 않는다. 원인을 수정한 뒤 새 `plan`과
새 승인을 만든다.

## 8. `apply`가 승인 내용을 보호하는 방식

`apply`는 다음 값이 모두 같을 때만 실행된다.

1. 제안의 SHA-256 digest와 승인서의 digest
2. 제안 생성 시점과 적용 시점의 patch/custom commit SHA
3. 제안 생성 시점과 적용 시점의 Manifest·Registry·Contract 입력 digest
4. `review-required.yaml`의 질문 목록과 승인서의 질문별 결정 목록

적용 중에는 `.registration-apply.lock`을 독점 생성한다. 각 파일은 임시 파일에
쓴 뒤 `os.replace`로 교체한다. 중간에 쓰기가 실패하면 이미 바꾼 파일을 적용 전
내용으로 되돌리고 잠금을 정리한다.

## 9. 실제 OM_TEMP 1.13.0 결과

- patch SHA: `2f4f3560e7a8437e2f4f7fcafd00d32ea2d91a50`
- custom SHA: `7d19c8952612e77467b0a80d6287170d814f1de1`
- 상태: `REVIEW_REQUIRED`
- 자동 등록 변경: 0건
- 기능별 사람 판단: 5건
- 차단: 0건
- 분석 오류: 0건
- 제안 digest:
  `sha256:502a6824bb60e02b0d6cf4a66043e9e5d9ec0b22ed70b2c3387437b738d278b7`

다섯 질문은 공식 patch에는 없는 기존 `watch` 경로를 계속 유지할지
BANK-OM별로 판단하는 내용이다. 승인과 `apply`는 아직 실행하지 않았다.

## 10. 테스트 코드와 검증 범위

| 테스트 파일 | 확인하는 내용 |
|---|---|
| `harness/tests/test_registration_prep.py` | 정상 분석, 후속 commit, ID 오류, 소유영역, watch 질문, stale 승인, 잠금, rollback |
| `harness/tests/test_gitprim.py` | commit·ID·경로·ref·tree 읽기와 Git 오류 구조화 |
| `harness/tests/test_candidate.py` | Candidate lock v1/v2, source-tree/build-artifact 구분과 결과 결속 |
| `harness/tests/test_registration_validation_workflow.py` | 생성된 등록자료의 실제 검증 흐름 |
| `harness/tests/test_source_candidate_workflow.py` | 등록 범위와 실제 소스 Candidate 검사 연결 |

집중 테스트는 다음과 같이 실행한다.

```bash
cd harness
../.venv/bin/python -m pytest \
  tests/test_registration_prep.py \
  tests/test_gitprim.py \
  tests/test_candidate.py \
  tests/test_registration_validation_workflow.py \
  tests/test_source_candidate_workflow.py
```

최신 원격 CI run `30468709056`은 `381 passed, 7 operational skips`로
성공했다. 이 결과는 소스와 등록자료 검사 증거이며 전체 Java/UI build,
행내 runtime, 실제 artifact 승격이나 운영 배포 완료를 뜻하지 않는다.

## 11. 현재 완료 범위와 남은 일

### 완료

- Git 기반 변경 분석
- BANK-OM별 commit inventory와 현재 diff 생성
- Manifest·Registry 변경 제안과 사람 질문 분리
- digest 결속 승인
- stale 입력·동시 적용 차단
- 원자 적용과 rollback
- Candidate lock v2의 source/build 구분
- 단위·통합·원격 fixed-mirror CI 검증
- 쉬운 사용 가이드와 운영 위키 반영

### 아직 실행하거나 결정하지 않은 것

- OM_TEMP 1.13.0의 watch 질문 5개 승인
- 승인된 제안의 실제 `apply`
- 조직 owner와 실제 승인자 지정
- 원격 1.13.1 patch/custom branch를 사용한 새 plan
- 전체 Java/UI build와 행내 runtime test
- 실제 이미지·패키지 digest 생성과 승격
- 운영 배포 승인과 내부망 반입

따라서 “검사 전 준비 자동화 구현과 사용 가이드”는 완료됐지만, “현재
OM_TEMP 변경의 승인·검사·배포”는 완료되지 않았다.
