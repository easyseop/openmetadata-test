# OM_TEMP 검사 전 사전 준비 자동화 설계서

> 문서 상태: Claude 독립 검토 반영 · 0~6단계 안전 구현 완료
> 작성 기준: `easyseop/openmetadata-test`의 `codex/strict-manifest-gates` branch
> 최초 검토 코드 기준 commit: `fb891934e9977427befdd5fb9832eadc8fe7ba01`
> 대상 제품 repository: `easyseop/OM_TEMP`
> 최초 적용 대상: `patch/om-1.13.0`과 `custom/om-1.13.0`
> 독립 검토 원문: 사용자 전달 `PREP_AUTOMATION_DESIGN_REVIEW_20260729.md`
> 반영 기록: `../04-진행/PREP_AUTOMATION_DESIGN_REVIEW_RESPONSE_20260729.md`

이 문서의 `plan`·`approval-template`·`apply` 명령은 2026-07-30
구현됐습니다. 실제 OM_TEMP 1.13.0 plan과 등록자료·소스 게이트 재검증까지
완료했습니다. 사람 승인, 원격에 없는 1.13.1 후보, 실제 runtime/build/deploy는
구현 완료 범위와 구분합니다.

## 1. 이 설계가 해결할 문제

현재 운영자는 BANK-OM commit이 추가될 때마다 다음 정보를 여러 파일에서 직접 맞춰야 합니다.

- 같은 BANK-OM ID의 후속 Git commit SHA
- 해당 BANK-OM ID가 변경한 전체 파일
- Manifest의 `implementation.changed_paths`
- 실제 변경 파일을 포함하는 `upgrade_watch.paths`
- 전체 custom branch의 변경 파일 목록
- 여러 BANK-OM ID가 함께 변경한 파일의 소유관계
- Registry, Manifest, Contracts 간 연결 상태

과거 `generate_manifest_drafts.py`는 BANK-OM별 Git commit SHA를 Python
코드에 직접 적었습니다. 현재는 하드코딩을 제거하고
`prepare_registration.py`의 Git 범위 분석을 호출하는 호환 진입점으로
교체했습니다.

이 설계의 목표는 개발자가 `Customization-ID`를 포함해 commit한 뒤, 한 번의 준비 절차로 검사 입력자료의 변경안을 생성하는 것입니다. 생성 결과는 자동으로 운영 파일을 덮어쓰지 않습니다. 담당자가 변경안을 확인하고 승인한 뒤에만 실제 등록 폴더에 반영합니다.

## 2. 구현 범위와 구현하지 않는 범위

### 2.1 이번 개발 범위

이번 개발은 검사 실행 전까지 필요한 준비 작업을 자동화합니다.

1. patch branch와 custom branch를 하나의 Git commit SHA로 고정합니다.
2. 두 branch 사이의 commit을 순서대로 읽습니다.
3. commit 메시지의 `Customization-ID`를 읽습니다.
4. BANK-OM ID별 commit SHA와 변경 파일을 계산합니다.
5. 기존 등록자료를 보존하면서 변경안을 생성합니다.
6. 자동으로 판단할 수 없는 항목을 한 목록으로 표시합니다.
7. 담당자가 승인한 동일한 변경안만 실제 등록 폴더에 반영합니다.
8. 등록자료 구조 검사를 실행해 검사기 입력으로 사용할 수 있는지 확인합니다.

### 2.2 이번 개발에서 자동 결정하지 않는 항목

Git은 파일과 commit 이력은 계산할 수 있지만 업무 의미는 판단할 수 없습니다. 다음 항목은 담당자가 결정합니다.

- 새 commit을 기존 BANK-OM ID의 후속 수정으로 볼지 별도 기능으로 볼지
- 새 파일을 `required_changed_paths`에 추가할지
- 수정하지 않은 의존 파일을 `upgrade_watch.paths`에 추가할지
- Contract의 업무 정상 조건
- 어떤 test가 기능을 증명하는 필수 test인지
- 신규 BANK-OM의 제목, 담당자, 중요도
- 충돌이 발생했을 때 공식 코드와 행내 코드 중 무엇을 유지할지

### 2.3 검사 실행 중 생성되는 자료

다음 자료는 준비 단계에서 성공 결과처럼 미리 만들지 않습니다. 실제 검사를 실행하면서 생성합니다.

- `candidate-lock.yaml`
- `test-run-set.yaml`
- `source-gate-results.json`
- `upgrade-watch-results.json`
- build, runtime, 배포 결과

## 3. 용어와 기준점

### 3.1 BANK-OM ID

`BANK-OM-007`처럼 하나의 커스터마이징 기능을 식별하는 번호입니다. 같은 기능의 누락 보완이나 오류 수정은 같은 ID를 사용할 수 있습니다.

### 3.2 Git commit SHA

Git이 commit마다 자동으로 생성하는 40자리 식별값입니다. 같은 BANK-OM ID에 여러 Git commit SHA가 있을 수 있습니다.

```text
BANK-OM-007
├─ 62e39da8...  최초 Tibero 구현
└─ 7d19c895...  누락 파일 보완
```

가장 최근 SHA 하나만 남기면 최초 commit이 변경한 파일의 근거를 잃습니다. 준비 도구는 patch와 custom 사이의 전체 commit을 읽어 같은 ID의 SHA를 순서대로 누적합니다.

### 3.3 공식 기준 SHA

`patch/om-1.13.0`이 가리키는 공식 OpenMetadata 1.13.0 코드입니다. 같은 제품 버전의 등록자료를 계산하는 시작점입니다.

### 3.4 현재 custom 기준 SHA

준비 명령을 실행할 때 `custom/om-1.13.0`이 가리키는 최신 commit입니다. 준비 도구는 명령 시작 시 이 branch를 SHA로 고정한 뒤 모든 파일을 같은 SHA 기준으로 계산합니다.

명령 실행 중 custom branch에 새 commit이 push되어도 현재 실행에는 섞이지 않습니다. 새 commit을 포함하려면 준비 명령을 다시 실행합니다.

### 3.5 Registry의 `source.snapshot_sha`

현재 Registry의 `source.snapshot_sha`는 과거 행내 소스 snapshot을 공식 원본에서 재구성할 때 사용하는 고정 기준입니다. 후속 commit이 생길 때마다 최신 custom HEAD로 바꾸지 않습니다.

이 설계는 다음 값을 분리합니다.

| 값 | 의미 | 갱신 시점 |
|---|---|---|
| `Registry source.snapshot_sha` | 과거 소스 재구성 기준 | 기준 snapshot 자체를 교체할 때만 |
| `Registry source.upstream_sha` | 해당 등록 버전의 공식 원본 기준 | 새 공식 버전 등록 폴더를 만들 때 |
| `commit-inventory custom_head_sha` | 준비 자료를 계산한 최신 custom 상태 | 준비 명령을 실행할 때마다 |
| `Candidate lock candidate.commit_sha` | 실제 검사한 custom 상태 | 검사 실행마다 |

## 4. 현재 구현 상태

### 4.1 현재 구현된 기능

- Git commit 경계를 보존한 commit 목록 조회
- commit 메시지의 `Customization-ID` 추출
- commit별 변경 파일 조회
- Manifest 구조 및 의미 검사
- Registry, Manifest, Contract 연결 검사
- 동일 ID의 여러 commit 허용 여부 검사
- Manifest 범위 밖 변경 검사
- Candidate lock 생성
- 실제 test 실행 후 test-run-set 생성

### 4.2 현재 자동화되지 않은 기능

- patch와 custom 사이의 모든 commit을 읽어 Manifest 초안을 만드는 통합 명령
- 후속 commit SHA 자동 발견
- 생성 전후 차이를 한곳에 보여주는 변경 제안
- 사람 판단이 필요한 항목만 모은 검토 목록
- 승인한 변경안과 적용할 변경안이 같은지 확인하는 digest 검증
- 버전별 `commit-inventory.yaml`
- 현재 custom HEAD 기준 최종 변경 목록

### 4.3 개발 전에 고쳐야 하는 기존 결함

독립 검토 당시 `harness/registrations/kb-openmetadata/run_source_candidate_gates.py`의 민감 영역 검사 입력은 Manifest v1 필드인 `allowed_changed_paths`와 `candidate_additional_paths`를 읽었습니다.

현재 Manifest v2는 `implementation.changed_paths`를 사용합니다. 0단계
기준선 복구에서 소스·업그레이드 실행기를 `manifest.declared_scope()`로
통일하고 Manifest v2 회귀 test를 추가했습니다. 이 수정은 자동화 본체 구현
완료를 뜻하지 않습니다.

이 결함 때문에 Manifest v2 전환 전에 저장한 OM_TEMP
`source-gate-results.json`의 T41 PASS를 현재 코드·현재 등록자료의 재실행
결과로 간주할 수 없습니다. 0단계에서는 다음 조건을 모두 충족해야 합니다.

1. 모든 소스·업그레이드 실행기가 schema-aware 공용 함수를 사용합니다.
2. Manifest v2 회귀 test가 통과합니다.
3. 공식 upstream object와 검사 후보 commit을 함께 가진 repository에서
   결과를 다시 실행합니다.
4. 원격에서 다시 만들 수 없는 후보의 과거 결과는 현재 증거와 구분합니다.

신규 Registry entry에는 `provenance`를 반드시 명시합니다. 과거 source
snapshot에 있던 ID는 `source-snapshot`, snapshot 이후 새로 추가한 ID는
`candidate-follow-up`입니다. 자동화는 이 값을 추측하지 않습니다.

## 5. 설계 결정

### D-01. Git을 BANK-OM별 commit 이력의 원본으로 사용한다

Manifest와 Registry에 BANK-OM별 SHA 목록을 사람이 중복 입력하지 않습니다. 준비 도구가 Git 이력에서 SHA 목록을 다시 계산합니다.

### D-02. 과거 재구성 기준과 현재 검사 기준의 역할을 분리하되 의존관계를 검사한다

다음 기존 파일은 과거 source snapshot 재구성 자료이므로 일반 후속 commit에서 갱신하지 않습니다.

- `source-diff-paths.txt`
- `source-snapshot-path-owners.yaml`
- `shared-path-owners.yaml`
- Registry의 `source.snapshot_sha`

현재 custom branch의 최신 상태는 새 자동 생성 자료에서 관리합니다.

- `commit-inventory.yaml`
- `current-diff-paths.txt`
- Manifest의 `implementation.changed_paths`
- 준비 제안서의 `custom_head_sha`
- 검사 실행 시 Candidate lock

두 자료 묶음은 완전히 독립적이지 않습니다.

- `source-snapshot-path-owners.yaml`의 ID별 경로는 현재 Manifest의
  `changed_paths`에 모두 포함돼야 합니다.
- 재구성 계획의 공용 경로 소유관계는 `shared-path-owners.yaml`과 같아야
  합니다.

이 조건이 깨지면 자동화는 제안서를 적용하지 않고 `BLOCKED`로 중단합니다.

### D-03. 생성과 적용을 분리한다

기본 명령은 실제 등록 폴더를 수정하지 않고 제안 폴더만 만듭니다.

```text
plan → 담당자 검토 → approve/apply → 등록자료 검사
```

### D-04. 사람 입력값은 재생성할 때 보존한다

기존 Manifest와 Registry의 다음 값은 자동 생성기가 덮어쓰지 않습니다.

- Manifest 제목, 상태, 종류
- `required_changed_paths`
- 변경하지 않은 watch 의존 경로
- `assurance.contracts`
- `assurance.direct_tests`
- `series.depends_on`
- Registry 제목, 담당자, 중요도, 상태
- Contract의 정상 조건과 필수 test

### D-05. Manifest v2만 생성한다

새 자동화는 다음 Manifest v1 필드를 생성하지 않습니다.

- `allowed_changed_paths`
- `candidate_additional_paths`

현재 버전의 실제 변경 범위는 `implementation.changed_paths` 하나로 관리합니다.

### D-06. 최근 N개 commit이 아니라 정확한 branch 범위를 읽는다

준비 도구는 다음 범위 전체를 읽습니다.

```text
patch/om-1.13.0..custom/om-1.13.0
```

최근 10개와 같이 임의 개수를 사용하면 오래된 BANK-OM commit이 누락될 수 있으므로 허용하지 않습니다.

## 6. 제안하는 파일 구조

```text
harness/
├─ prepare_registration.py
├─ acgh/
│  ├─ registration_prep.py
│  ├─ registration_proposal.py
│  ├─ registration_apply.py
│  └─ schema/
│     ├─ commit-inventory.schema.json
│     ├─ registration-proposal.schema.json
│     └─ registration-approval.schema.json
└─ registrations/
   └─ om-temp-1.13.0/
      ├─ customization-registry.yaml
      ├─ contracts.yaml
      ├─ commit-inventory.yaml
      ├─ current-diff-paths.txt
      ├─ manifests/
      └─ ...
```

실행 중 변경안은 Git에 바로 저장하지 않고 작업 폴더에 생성합니다.

```text
.work/
└─ registration-proposals/
   └─ om-temp-1.13.0-<custom-head-short-sha>/
      ├─ proposal.yaml
      ├─ proposal-digest.txt
      ├─ summary.md
      ├─ review-required.yaml
      ├─ diff.patch
      └─ proposed-registration/
```

## 7. 자동 생성 파일 설계

### 7.1 `commit-inventory.yaml`

#### 의미

해당 제품 버전에서 patch와 custom 사이의 commit을 BANK-OM ID별로 정리한 자동 생성 자료입니다.

#### 생성·갱신 시점

준비 명령을 실행할 때마다 Git 이력에서 새로 만듭니다.

#### 실제 사용

- Manifest `changed_paths` 계산 근거
- 후속 commit 자동 발견
- 같은 ID의 여러 commit 순서 확인
- 변경 제안 요약
- 검사에서 사용한 범위의 추적

#### 예시

```yaml
schema_version: 1
product_version: 1.13.0
range:
  patch_ref: patch/om-1.13.0
  patch_sha: <patch/om-1.13.0이 실제로 가리키는 40자리 SHA>
  custom_ref: custom/om-1.13.0
  custom_head_sha: 7d19c8952612e77467b0a80d6287170d814f1de1
customizations:
  BANK-OM-007:
    commits:
      - sha: 62e39da8be65c3ff259802c1cd35f4b0c8baa333
        subject: add Tibero customization
      - sha: 7d19c8952612e77467b0a80d6287170d814f1de1
        subject: complete Tibero service connection coverage
    latest_commit_sha: 7d19c8952612e77467b0a80d6287170d814f1de1
    changed_paths:
      - openmetadata-spec/src/main/resources/json/schema/entity/services/connections/database/tiberoConnection.json
      - openmetadata-spec/src/main/resources/json/schema/entity/services/databaseService.json
      - openmetadata-ui/src/main/resources/ui/src/assets/svg/service-icon-tibero.svg
      - openmetadata-ui/src/main/resources/ui/src/generated/api/services/createDatabaseService.ts
      - openmetadata-ui/src/main/resources/ui/src/generated/entity/services/connections/database/tiberoConnection.ts
      - openmetadata-ui/src/main/resources/ui/src/generated/entity/services/databaseService.ts
      - openmetadata-ui/src/main/resources/ui/src/utils/DatabaseServiceUtils.tsx
      - openmetadata-ui/src/main/resources/ui/src/utils/ServiceIconUtils.ts
      - openmetadata-ui/src/main/resources/ui/src/generated/entity/services/connections/serviceConnection.ts
      - openmetadata-ui/src/main/resources/ui/src/utils/DatabaseServiceUtils.test.tsx
```

#### 검사 결과

- 모든 대상 commit이 정확히 하나의 등록된 ID를 가지면 `READY`
- ID가 없거나 여러 개이면 `BLOCKED`
- 신규 ID이면 초안 생성 후 `REVIEW_REQUIRED`
- 같은 ID의 모든 commit이 변경한 경로의 합집합이어야 T40·T93 검사를
  통과합니다. BANK-OM-007의 실제 합집합은 10개입니다.

### 7.2 `current-diff-paths.txt`

#### 의미

준비 명령이 고정한 patch SHA와 custom HEAD SHA의 최종 파일 차이입니다.

#### 생성·갱신 시점

준비 명령 실행마다 새로 만듭니다.

#### 실제 사용

- 최종 custom 코드에 남아 있는 변경 파일 확인
- commit 도중 변경했다가 되돌린 파일과 최종 변경 파일 구분
- 등록되지 않은 최종 변경 파일 탐지

#### 주의

Manifest의 `changed_paths`는 해당 ID의 commit이 변경한 파일을 기록합니다. `current-diff-paths.txt`는 patch와 custom의 최종 결과가 다른 파일만 기록합니다.

예를 들어 한 commit이 파일을 수정하고 뒤 commit이 공식 상태로 되돌리면:

- Manifest `changed_paths`: 해당 파일 포함
- `current-diff-paths.txt`: 해당 파일 제외
- 준비 결과: 되돌림 사실을 `REVIEW_REQUIRED`로 표시

### 7.3 `registration-proposal.yaml`

#### 의미

자동화가 계산한 변경안과 담당자 판단이 필요한 항목을 함께 기록합니다.

#### 예시

```yaml
schema_version: 1
product_version: 1.13.0
patch_sha: <patch/om-1.13.0이 실제로 가리키는 40자리 SHA>
custom_head_sha: 7d19c8952612e77467b0a80d6287170d814f1de1
changes:
  - customization_id: BANK-OM-007
    action: update_existing
    new_commits:
      - 7d19c8952612e77467b0a80d6287170d814f1de1
    added_changed_paths:
      - openmetadata-ui/src/main/resources/ui/src/generated/entity/services/connections/serviceConnection.ts
      - openmetadata-ui/src/main/resources/ui/src/utils/DatabaseServiceUtils.test.tsx
    removed_changed_paths: []
review_required:
  - code: REQUIRED_PATH_DECISION
    customization_id: BANK-OM-007
    path: openmetadata-ui/src/main/resources/ui/src/generated/entity/services/connections/serviceConnection.ts
    question: 이 파일이 누락되면 Tibero 기능이 적용되지 않는가?
blocked: []
```

### 7.4 `registration-approval.yaml`

#### 의미

담당자가 어떤 제안서를 승인했는지 기록합니다.

#### 예시

```yaml
schema_version: 1
proposal_digest: sha256:<64자리>
approved_by: employee-id
approved_at: 2026-07-29T12:00:00Z
decisions:
  - code: REQUIRED_PATH_DECISION
    customization_id: BANK-OM-007
    path: openmetadata-ui/src/main/resources/ui/src/generated/entity/services/connections/serviceConnection.ts
    decision: keep_changed_only
    reason: 핵심 스키마가 아니라 UI 보조 등록 파일이므로 required에는 추가하지 않음
```

적용 명령은 승인서의 digest와 현재 제안서 digest가 다르면 중단합니다. 담당자가 승인한 뒤 custom branch가 바뀌었거나 제안 파일이 수정된 경우 이전 승인을 재사용하지 못합니다.

## 8. 파일별 자동 갱신 규칙

| 파일·필드 | 기존 ID 후속 commit | 새 공식 버전 | 사람이 결정하는 항목 |
|---|---|---|---|
| `commit-inventory.yaml` | 전체 자동 재생성 | 새 버전 폴더에서 자동 생성 | 없음 |
| `current-diff-paths.txt` | 전체 자동 재생성 | 새 버전 폴더에서 자동 생성 | 없음 |
| Manifest `changed_paths` | ID별 commit 이력으로 자동 갱신 | 새 버전 이력으로 다시 계산 | 없음 |
| Manifest `required_changed_paths` | 기존 값 보존, 새 파일은 질문 생성 | 새 버전에서 유효성 재검토 | 필수 파일 여부 |
| `upgrade_watch.paths` | 공식 upstream tree에 존재하는 실제 변경 경로만 자동 포함, 기존 의존 경로 보존 | 공식 구조 변경에 맞춰 재검토 | 행내 신규 파일과 간접 의존 경로 |
| `series.allowed` | 기존 값을 유지하고 `false`에서 후속 commit이 발견되면 적용 중단 | 새 버전 Manifest 정책에 따라 유지 | `false`에서 후속 commit 허용 여부 |
| Registry entry | 기존 사람 값 보존 | 같은 ID를 새 버전 Registry에 연결 | 담당자·중요도·상태 |
| Contracts | 자동 변경하지 않음 | 업무 정상 조건이 같으면 복사 | 정상 조건·필수 test |
| `source-diff-paths.txt` | 변경하지 않음 | 새 source snapshot을 등록할 때 생성 | source snapshot 교체 승인 |
| `source-snapshot-path-owners.yaml` | 변경하지 않음 | 새 source snapshot 등록 시 생성 | 예외 소유관계 승인 |
| `shared-path-owners.yaml` | 변경하지 않음 | 새 source snapshot 등록 시 생성 | 공용 snapshot 경로 소유 승인 |
| Candidate lock | 준비 단계에서 만들지 않음 | 검사 실행마다 자동 생성 | 검사 대상 승인 |
| test-run-set | 준비 단계에서 만들지 않음 | 실제 test마다 자동 생성 | test 결과 승인·재실행 판단 |

## 9. 준비 명령 인터페이스

아래 명령은 현재 구현된 인터페이스입니다.

### 9.1 변경안 생성

```bash
python harness/prepare_registration.py plan \
  --repo /path/to/OM_TEMP \
  --registration harness/registrations/om-temp-1.13.0 \
  --patch-ref patch/om-1.13.0 \
  --custom-ref custom/om-1.13.0 \
  --product-version 1.13.0 \
  --output .work/registration-proposals/om-temp-1.13.0
```

#### 성공 출력 예시

```text
PREPARATION STATUS: REVIEW_REQUIRED
patch:  <patch/om-1.13.0이 실제로 가리키는 40자리 SHA>
custom: 7d19c8952612e77467b0a80d6287170d814f1de1
registered IDs: 7
new follow-up commits: 1
automatic file updates: 4
human decisions: 1
blocked findings: 0
proposal: .work/registration-proposals/om-temp-1.13.0/proposal.yaml
```

### 9.2 승인안 적용

```bash
python harness/prepare_registration.py apply \
  --repo /path/to/OM_TEMP \
  --proposal .work/registration-proposals/om-temp-1.13.0/proposal.yaml \
  --approval .work/registration-proposals/om-temp-1.13.0/registration-approval.yaml \
  --registration harness/registrations/om-temp-1.13.0
```

적용 명령은 다음 조건을 모두 확인합니다.

- 제안서 digest와 승인서 digest가 같다.
- patch SHA와 custom HEAD SHA가 제안 생성 시점과 같다.
- 등록 폴더가 제안 생성 이후 변경되지 않았다.
- 모든 `REVIEW_REQUIRED` 항목에 결정이 있다.
- `BLOCKED` 항목이 없다.

### 9.3 등록자료 검사

적용이 끝나면 기존 등록자료 검사기를 실행합니다.

```bash
python harness/registrations/om-temp-1.13.0/validate_registration_bundle.py \
  --repo /path/to/OM_TEMP \
  --registration harness/registrations/om-temp-1.13.0 \
  --output harness/registrations/om-temp-1.13.0/registration-validation-results.json
```

## 10. 처리 순서

```text
1. 입력 확인
   ├─ 제품 repository 존재
   ├─ patch/custom ref 존재
   ├─ 등록 폴더 존재
   └─ 미commit 변경 없음
          ↓
2. 기준 고정
   ├─ patch ref → patch SHA
   └─ custom ref → custom HEAD SHA
          ↓
3. Git 이력 분석
   ├─ patch..custom 전체 commit
   ├─ commit별 Customization-ID
   └─ commit별 변경 파일
          ↓
4. 등록자료와 비교
   ├─ 기존 ID / 신규 ID
   ├─ Manifest changed_paths
   ├─ required/watch/Contract 유효성
   └─ 최종 diff와 ID 소유관계
          ↓
5. 제안 생성
   ├─ 자동 변경 파일
   ├─ 사람이 판단할 질문
   └─ 즉시 중단할 오류
          ↓
6. 담당자 검토·승인
          ↓
7. digest 확인 후 적용
          ↓
8. 등록자료 검사
          ↓
9. 실제 검사기 실행
```

## 11. 판정과 다음 행동

| 준비 상태 | 의미 | 다음 행동 |
|---|---|---|
| `READY` | 자동 변경만 있으며 사람 판단 질문과 차단 오류가 없음 | 담당자가 diff를 확인하고 승인 |
| `REVIEW_REQUIRED` | 업무 의미를 판단해야 하는 항목이 있음 | 질문에 답하고 승인서를 작성한 뒤 다시 적용 |
| `BLOCKED` | 신뢰할 수 있는 변경안을 만들 수 없음 | 원인을 수정하고 `plan`부터 다시 실행 |
| `ANALYSIS_ERROR` | 입력이나 정책이 불완전해 자동 판단 자체를 신뢰할 수 없음 | 누락된 object·경로 정책·등록자료를 복구하고 처음부터 재실행 |
| `ERROR` | Git 명령, 파일 읽기, schema 처리 자체가 실패 | 환경과 입력 경로를 수정하고 재실행 |

`READY`도 자동 적용하지 않습니다. 사용자의 요구대로 모든 변경안은 사람이 최종 승인합니다.

## 12. 차단 조건

다음 조건에서는 변경안을 실제 파일에 적용하지 않습니다.

1. custom branch에 commit되지 않은 변경이 있다.
2. patch ref 또는 custom ref가 존재하지 않는다.
3. patch와 custom의 관계를 하나의 범위로 계산할 수 없다.
4. Core 파일을 변경한 commit에 `Customization-ID`가 없다.
5. 하나의 commit에 여러 `Customization-ID`가 있다.
6. 대상 범위에 merge commit이 있다.
7. commit이 등록되지 않은 ID를 사용했지만 신규 ID 필수 정보가 없다.
8. 변경 경로가 `repository-layout.yaml`에서 어떤 영역인지 분류되지 않는다.
9. 기존 `required_changed_paths`가 새 `changed_paths` 범위에서 사라진다.
10. 승인 후 patch SHA, custom HEAD SHA 또는 등록 폴더가 바뀌었다.
11. 제안서 digest와 승인서 digest가 다르다.
12. Registry의 `upstream_sha` 또는 `snapshot_sha` object가 제품 repository에 없다.
13. `source-snapshot-path-owners.yaml`의 ID별 경로가 현재 `changed_paths`에서 빠진다.
14. 재계산한 공용 경로 소유관계가 `shared-path-owners.yaml`과 다르다.
15. 신규 ID의 Registry entry에 명시적인 `provenance`가 없다.
16. 빈 commit, Core·governance 혼합 commit 또는 governance commit의 Core 변경이 있다.
17. 같은 ID의 commit 사이에 다른 ID가 끼거나 retired ID를 다시 사용한다.
18. patch와 custom이 무관한 Git 이력이라 merge base를 계산할 수 없다.
19. symlink·submodule·Git LFS pointer처럼 현재 지원하지 않는 경로 mode가 있다.
20. 실제 검사 직전 Candidate lock의 commit SHA가 승인한 `custom_head_sha`와 다르다.
21. 현재 등록 폴더에 대한 등록자료 검사가 통과하지 않았다.
22. 다른 작업자가 등록 폴더를 변경했거나 apply 잠금을 보유하고 있다.

## 13. 정상·실패 예시

### 13.1 기존 ID의 정상 후속 commit

```bash
git commit -m "Tibero UI 누락 보완" \
  -m "Customization-ID: BANK-OM-007"
```

준비 도구의 동작:

1. 새 SHA를 BANK-OM-007 이력에 자동 추가
2. 새 변경 파일을 BANK-OM-007 `changed_paths`에 추가
3. 공식 upstream tree에도 존재하는 경로만 `upgrade_watch.paths` 후보에 추가
4. `required_changed_paths` 추가 여부를 담당자에게 질문
5. 다른 사람 입력값은 그대로 유지

### 13.2 ID가 없는 Core 변경

```text
commit aaaaaaaaaaaa
changed: openmetadata-service/src/main/java/org/openmetadata/service/Entity.java
Customization-ID: 없음
```

출력:

```text
PREPARATION STATUS: BLOCKED
CORE_CHANGE_WITHOUT_ID
commit: aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
path: openmetadata-service/src/main/java/org/openmetadata/service/Entity.java
next action: commit 메시지에 올바른 BANK-OM ID를 넣어 새 commit으로 보완한 뒤 plan 재실행
```

도구가 임의 ID를 추측해 지정하지 않습니다.

### 13.3 신규 ID

```text
Customization-ID: BANK-OM-008
Registry entry: 없음
```

출력:

```text
PREPARATION STATUS: REVIEW_REQUIRED
NEW_CUSTOMIZATION
required input:
- title
- owner
- criticality
- kind
- provenance
- required_changed_paths
- 하나 이상의 Contract
- 필요한 경우 direct tests
```

담당자가 필수 정보를 제공하기 전에는 최종 Manifest와 Registry entry를 적용하지 않습니다.

## 14. 기존 코드 변경 계획

### 14.1 재사용할 코드

- `acgh.gitprim.commits()`: commit 순서와 trailer 조회
- `acgh.gitprim.changed_paths()`: commit별 변경 파일
- `acgh.gitprim.net_changed_paths()`: patch와 custom의 최종 차이
- `acgh.manifest.validate_manifest()`: Manifest v2 검사
- `acgh.registry.validate_references()`: Registry·Manifest·Contract 연결 검사
- `acgh.invariants`: ID 누락, 여러 ID, merge, series 검사
- `acgh.policy_drift.check_exact_scope_history()`: ID별 실제 이력과 Manifest 범위 비교
- `validate_registration_bundle.py`: 적용 후 등록자료 검사

### 14.2 제거·대체할 코드

`generate_manifest_drafts.py`의 하드코딩된 `CUSTOMIZATIONS[*].commits`는
제거했습니다. 사람 정책값은 Python 상수가 아니라 기존 Manifest와
Registry에서 읽습니다.

같은 파일의 `series.allowed = len(commits) > 1` 자동 유도도 제거합니다.
후속 commit이 발견돼도 기존 `false`를 자동으로 `true`로 바꾸지 않습니다.
모든 Git 경로 조회는 한글·공백 파일명을 손상하지 않도록
`acgh.gitprim`을 경유합니다.

`generate_registration_bundle.py`는 다음 두 역할로 분리합니다.

1. 과거 source snapshot 등록을 처음 만드는 별도 도구
2. 현재 custom 후속 commit을 준비하는 새 자동화 도구

일반 후속 commit 때문에 source snapshot 자료가 다시 생성되지 않도록 합니다.

### 14.3 반드시 함께 수정할 코드

`run_source_candidate_gates.py`와 `run_upgrade_risk_gates.py`가 모두
`manifest.declared_scope()`를 사용하도록 통일합니다.

## 15. 테스트 설계

### 15.1 단위 test

임시 Git repository를 만들어 다음 경우를 검증합니다.

| test | 예상 결과 |
|---|---|
| 기존 ID commit 1개 | SHA와 변경 파일 자동 발견 |
| 같은 ID 후속 commit | SHA 누적, changed_paths 합집합 |
| 새 ID | `REVIEW_REQUIRED` |
| ID 없는 Core commit | `BLOCKED` |
| 여러 ID가 있는 commit | `BLOCKED` |
| merge commit | `BLOCKED` |
| `repository-layout.yaml`에서 분류되지 않는 경로 | `BLOCKED` |
| 파일 수정 후 원복 | Manifest touched 범위와 최종 diff를 분리 |
| 파일 rename | 이전·신규 경로 처리 검증 |
| 한글 파일명 | NUL 구분 Git 조회 검증 |
| 기존 required/watch/Contract | 재생성 후 값 보존 |
| 승인 뒤 custom HEAD 변경 | apply 차단 |
| 승인 digest 불일치 | apply 차단 |
| Manifest v2 T41 | `changed_paths`를 실제 허용 범위로 사용 |
| 후속 commit | source snapshot 파일이 바뀌지 않음 |
| 1.13.0과 1.13.1 | 버전 폴더 상호 덮어쓰기 없음 |
| 신규 ID에 provenance 없음 | `BLOCKED` |
| source owner 경로 누락 | `BLOCKED` |
| 공용 경로 소유맵 불일치 | `BLOCKED` |
| 빈 commit·Core/governance 혼합 | `BLOCKED` |
| 비연속 series·retired ID 재사용 | `BLOCKED` |
| patch/custom 무관 이력 | `ANALYSIS_ERROR` |
| symlink·submodule·LFS pointer | `BLOCKED` |
| 승인 SHA와 Candidate lock SHA 불일치 | `BLOCKED` |
| 동시 apply 또는 등록 폴더 변경 | `BLOCKED` |
| 공식 tree에 없는 watch 후보 | 자동 포함하지 않고 `REVIEW_REQUIRED` |

### 15.2 통합 test

1. 실제 OM_TEMP 1.13.0 commit 이력으로 `plan` 실행
2. 기존 BANK-OM-001~007과 SHA 순서 비교
3. 생성된 Manifest `changed_paths`와 현재 수동 등록자료 비교
4. 제안 적용 후 등록자료 검사 실행
5. source candidate gate 실행
6. 두 번째 실행에서 변경이 없으면 빈 diff가 생성되는지 확인

### 15.3 회귀 test

전체 harness test를 실행합니다.

```bash
pytest -q harness/tests
```

### 15.4 합격 조건

- 모든 신규 단위 test 통과
- 기존 전체 test 통과
- 실제 OM_TEMP 1.13.0에서 BANK-OM-001~007 자동 발견
- 하드코딩된 BANK-OM commit SHA 제거
- 두 번째 동일 실행 결과가 동일함
- 사람 입력값이 자동 생성으로 변경되지 않음
- 승인하지 않은 변경안이 실제 등록 폴더에 반영되지 않음
- Manifest v2 source gate가 실제 `changed_paths`를 사용함

## 16. 보안·안전 설계

- Manifest나 승인 파일에서 임의 shell command를 읽어 실행하지 않습니다.
- Git 조회 명령의 repository와 ref는 인자로 분리해 전달합니다.
- 출력 경로가 등록 폴더 밖인지 plan 단계에서 확인합니다.
- apply 단계는 임시 파일을 만든 뒤 원자적으로 교체합니다.
- symlink, submodule, Git LFS pointer는 Git tree mode·blob 내용 검사로
  plan 단계에서 차단합니다.
- dirty worktree는 포함되지 않은 변경을 놓칠 수 있으므로 plan을 차단합니다.
- 제안서와 승인서에 SHA-256 digest를 사용합니다.
- 자동 생성 파일은 결정론적으로 정렬해 같은 입력에서 같은 결과가 나오게 합니다.

## 17. 도입 순서

2026-07-30 현재 0~6단계의 코드·단위 test·1.13.0 실데이터 검증·문서 반영이
완료됐습니다. 아래 목록은 구현 순서 기록이며, 1.13.1과 운영 실행은 외부 입력
대기입니다.

### 0단계: 기준선 복구

- Manifest v2 T41 입력 수정
- 신규 ID provenance 명시 강제
- Manifest v2 통합 test 추가
- 과거 결과의 재현 가능 여부 표시
- 공식 upstream object를 포함한 repository에서 결과 재실행

### 1단계: 읽기 전용 분석기

- Git 범위 고정
- BANK-OM별 SHA·경로 자동 발견
- `commit-inventory.yaml`과 `current-diff-paths.txt`만 제안 폴더에 생성

### 2단계: 차단 판정기

- 모든 차단 조건과 Git edge case를 파일 쓰기 없이 판정
- `READY`·`REVIEW_REQUIRED`·`BLOCKED`·`ANALYSIS_ERROR`·`ERROR` 구분

### 3단계: 제안서와 사람 판단 목록

- `proposal.yaml`, `review-required.yaml`, `diff.patch`, `summary.md`
- 사람 입력값 보존 test

### 4단계: 안전한 `apply`

- proposal digest
- approval digest
- 기준 SHA 재확인
- 사람 입력값 보존
- 등록 폴더 잠금
- 원자적 파일 교체

### 5단계: 실제 OM_TEMP 검증

- 1.13.0에서 BANK-OM-001~007 재현
- 후속 commit 시나리오 검증
- 등록자료 검사와 source gate 실행
- 1.13.1은 원격 branch와 후보 commit이 준비된 뒤 검증

### 6단계: 운영 가이드 반영

- 위키에 자동/사람 경계 반영
- 정상·실패 예시 반영
- 신입사원용 실행 순서와 복구 절차 반영
- 인수인계서와 원격 repository 갱신

## 18. 되돌리기

준비 도구의 `plan`은 실제 등록 폴더를 수정하지 않으므로 제안 폴더만 폐기하면 됩니다.

`apply` 이후 문제가 발견되면 파괴적인 Git 명령을 사용하지 않습니다. 적용 commit을 별도 revert commit으로 되돌린 뒤, 원인을 수정하고 `plan`부터 다시 실행합니다.

## 19. Claude에게 검토받을 핵심 질문

1. Registry의 고정 source snapshot과 현재 custom HEAD를 분리한 구조가 기존 재구성 검사와 충돌하지 않는가?
2. `commit-inventory.yaml`을 Git 이력에서 매번 재생성하는 방식이 감사 이력과 재현성을 모두 만족하는가?
3. Manifest `changed_paths`와 `current-diff-paths.txt`를 touched 범위와 최종 net diff로 나눈 설명과 검사 방식이 올바른가?
4. 기존 사람이 관리하는 required, watch 의존, Contract 값을 보존하는 방식에 누락 위험이 없는가?
5. `plan → approval digest → apply` 구조가 승인 후 입력 변경을 충분히 차단하는가?
6. 신규 ID에서 자동으로 추측하지 않고 `REVIEW_REQUIRED`로 중단하는 정책이 적절한가?
7. merge commit을 준비 단계에서 차단하는 기존 정책을 유지해야 하는가?
8. source snapshot 관련 기존 세 파일을 일반 후속 commit에서 갱신하지 않는 결정이 코드 사용처와 일치하는가?
9. 현재 `shared-path-owners.yaml` 이름이 최신 소유정보처럼 오해될 수 있으므로 이름 변경이나 설명 보강이 필요한가?
10. 단위·통합·회귀 test에서 빠진 실패 경로가 있는가?

## 20. 구현 완료 정의

다음 조건이 모두 충족돼야 자동화 구현이 완료된 것으로 판단합니다.

1. 개발자가 올바른 BANK-OM ID로 commit한다.
2. 준비 도구가 patch와 custom의 정확한 SHA를 고정한다.
3. 준비 도구가 기존 ID의 모든 SHA와 변경 파일을 자동 발견한다.
4. 준비 도구가 사람 판단값을 변경하지 않고 제안을 만든다.
5. 담당자가 한 화면 또는 한 파일에서 모든 판단 항목을 확인한다.
6. 승인한 제안서만 실제 등록 폴더에 반영된다.
7. 등록자료 검사가 통과한다.
8. 실제 검사기는 같은 custom HEAD SHA를 사용한다.
9. 검사 실행 결과 파일은 실제 실행 뒤에만 생성된다.
10. 신규 test와 기존 전체 test가 모두 통과한다.
11. 위키와 인수인계서가 실제 구현과 동일한 절차를 설명한다.
